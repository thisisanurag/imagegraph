package com.example.messenger3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Choose extends AppCompatActivity implements View.OnClickListener{

    private Button encode;
    private Button decode;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);
        encode=(Button)findViewById(R.id.encode);
        decode=(Button)findViewById(R.id.decode);
        encode.setOnClickListener(this);
        decode.setOnClickListener(this);

    }
    @Override
    public void onClick(View view)
    {
        switch (view.getId()) {
            case R.id.encode:
                Intent intent = new Intent(this, image.class);
                startActivity(intent);
                break;
            case R.id.decode:
                break;
        }
    }
}
