package com.example.messenger3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.graphics.Color;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class image extends AppCompatActivity implements View.OnClickListener {
    public static final int PICK_IMAGE = 1;
    private ImageView imageView;
    private EditText text;
    private Button go;
    private Uri filePath;
    private Bitmap bitmap = null;
    private Bitmap img = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = (ImageView) findViewById(R.id.imgView);
        text = (EditText) findViewById(R.id.text);
        go = (Button) findViewById(R.id.go);
        go.setOnClickListener(this);
        chooseImage();
    }

    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            filePath = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                imageView.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void process() {
        String str = "";
        str = text.getText().toString();
        int len = str.length();
        System.out.println("Message length=" + len);
        int count = 0;
        char ch = ' ';
        int p = 0, a = 0, r = 0, g = 0, b = 0, k = 0;
        int i = 0, j = 0;
        try {
            img = bitmap;
            //get image width and height
            int width = img.getWidth();
            int height = img.getHeight();
            for (i = 0; i < width; i++) {
                for (j = 0; j < height; j++) {

                    p = img.getPixel(i, j);// getting the RGB values at specified pixel
                    // get alpha
                    a = (p >> 24) & 0xff;

                    // get red
                    r = (p >> 16) & 0xff;
                    // get green
                    g = (p >> 8) & 0xff;

                    // get blue
                    b = p & 0xff;
                    if (count < str.length()) { // if a character exists to encode
                        if (i == 0 && j == 0) {
                            ch = (char) len;
                        } else {
                            ch = str.charAt(count);// extracting a character
                            count++;
                        }
                        System.out.println(Integer.toBinaryString(ch));
                        //encoding last 2 bits of character in last two bits of a
                        k = ch & (0x3);
                        a = a & (0xfc);
                        a = a | k;
                        System.out.println("a" + Integer.toBinaryString(a) + "   " + i + j);
                        //encoding next 2 bits of char in last two bits of r and so on
                        k = ch & (0xc);
                        r = r & (0xfc);
                        k = k >> 2;
                        r = r | k;
                        System.out.println(Integer.toBinaryString(r));

                        k = ch & (0x30);
                        g = g & (0xfc);
                        k = k >> 4;
                        g = g | k;
                        System.out.println(Integer.toBinaryString(g));

                        k = ch & (0xc0);
                        b = b & (0xfc);
                        k = k >> 6;
                        b = b | k;
                        System.out.println(Integer.toBinaryString(b));
                    }
                    // if no char is there to encode then simply reform the previous p
                    p = (a << 24) | (r << 16) | (g << 8) | b;
                    img.setPixel(i, j, p);
                }
            }
            OutputStream fOut = null;
            File file = new File("/sdcard/", "b.png");
            file.createNewFile();
            fOut = new FileOutputStream(file);
            // 100 means no compression, the lower you go, the stronger the compression
            img.compress(Bitmap.CompressFormat.PNG, 100, fOut);
            fOut.flush();
            fOut.close();

            MediaStore.Images.Media.insertImage(getContentResolver(), file.getAbsolutePath(), file.getName(), file.getName());
            Toast.makeText(getApplicationContext(), "Successfully Encoded", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "" + e + i + "," + j, Toast.LENGTH_SHORT).show();
            //Toast.makeText(getApplicationContext(),e.toString(), Toast.LENGTH_SHORT).show();
            //System.out.println(e);
        }

        //System.out.println("END of programme");
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.go:
                process();
                break;
        }
    }
}
